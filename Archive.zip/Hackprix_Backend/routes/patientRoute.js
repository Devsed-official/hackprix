import express from 'express';
import { PatientLogin, PatientRegistration, Verifycode, handleAllCallback, addInsurances,getAllDoctors, addMedicalHistory, askForCharityOrNot, bookASlot, bookTests, changePassword, dashboardHit, getAllAppointments, getAllMedicalHistory, getAllTests, getDoctorSchedule, getFilteredTestProviders, getHistoryById, getPatient, getTestById, newPassword, sendVerification, sendVerifyCode, talkWithAi, updateHabits, updatePatientDetails, verifyPhone, googleLoginReg, callbackGoogle } from '../controllers/patientController.js';
import { protectPatient } from '../middleware/middleware.js';
import upload from '../utils/upload.js';
import { createTokenFreeTrial } from '../controllers/roomController.js';
const router = express.Router();

router.route("/get").get(protectPatient, getPatient);
router.route("/register").post(PatientRegistration);
router.route("/login").post(PatientLogin);
router.route("/update").post(protectPatient, updatePatientDetails);
router.route("/sendOtp").post(protectPatient, sendVerification);
router.route("/verifyOtp").post(protectPatient, verifyPhone);
router.route("/sendVerificationCode").post(sendVerifyCode);
router.route("/verifyCode").post(Verifycode);
router.route("/newPassword").post(protectPatient, newPassword);
router.route("/changePassword").post(protectPatient, changePassword);
router.route("/updateHabits").post(protectPatient, updateHabits);
router.route("/askCharityOrNot").post(protectPatient, askForCharityOrNot);
router.route("/addMedicalHistory").post(protectPatient,upload.array('documents', 10), addMedicalHistory);
router.route("/addInsurance").post(protectPatient, addInsurances);
router.route("/talkWithAi").post(protectPatient, talkWithAi);
router.route("/bookASlot").post(protectPatient, bookASlot);
router.route("/joinMeet").post(protectPatient, createTokenFreeTrial);
router.route("/getFilteredTestProviders").post(protectPatient, getFilteredTestProviders);
router.route("/bookTests").post(protectPatient, bookTests);
router.route("/dashboardHit").get(protectPatient, dashboardHit);
router.route("/medicalTimeline").get(protectPatient, getAllMedicalHistory);
router.route("/historyById/:id").get(protectPatient, getHistoryById);
router.route("/doctorSchedule/:doctorId").get(protectPatient, getDoctorSchedule);
router.route("/all").get(protectPatient, getDoctorSchedule);
router.route("/getAllAppointments").get(protectPatient, getAllAppointments);
router.route("/getAllDoctors").get(protectPatient, getAllDoctors);
router.route("/getAllTests").get(protectPatient, getAllTests);
router.route("/getTestById/:id").get(protectPatient, getTestById);


router.route('/auth/google').get(googleLoginReg);
router.route('/auth/google/callback').get(callbackGoogle, handleAllCallback);


export default router;