import express from 'express';
import { addAdminUser, addCategories, addHospital, addTestProvider, addTests, adminLogin } from '../controllers/adminController.js';
import { checkAdmin, protect } from '../middleware/middleware.js';
const router = express.Router();

router.route("/addAdmin").post(addAdminUser);
router.route("/login").post(adminLogin);
router.route("/addHospital").post(protect, checkAdmin, addHospital);
router.route("/addCategory").post(protect, checkAdmin, addCategories);
router.route("/addTest").post(protect, checkAdmin, addTests);
router.route("/addTestProvider").post(protect, checkAdmin, addTestProvider);

export default router;