import express from "express";
import {
  DoctorLogin,
  DoctorRegistration,
  PatientMedicalHistory,
  Verifycode,
  changePassword,
  doctorSchedule,
  getDoctor,
  getDoctorSchedule,
  newPassword,
  sendVerification,
  sendVerifyCode,
  updateDoctorDetails,
  updatePatientMedicalHistory,
  updateSchedule,
  verifyPhone,
} from "../controllers/doctorController.js";
import { protectDoctor } from "../middleware/middleware.js";
import { createTokenFreeTrial } from "../controllers/roomController.js";
import upload from "../utils/upload.js";
const router = express.Router();

router.route("/get").get(protectDoctor, getDoctor);
router.route("/register").post(DoctorRegistration);
router.route("/login").post(DoctorLogin);
router.route("/update").post(protectDoctor, updateDoctorDetails);
router.route("/sendOtp").post(protectDoctor, sendVerification);
router.route("/verifyOtp").post(protectDoctor, verifyPhone);
router.route("/sendVerificationCode").post(sendVerifyCode);
router.route("/verifyCode").post(Verifycode);
router.route("/newPassword").post(protectDoctor, newPassword);
router.route("/changePassword").post(protectDoctor, changePassword);
router.route("/createSchedule").post(protectDoctor, doctorSchedule);
router.route("/updateSchedule").post(protectDoctor, updateSchedule);
router.route("/updateSchedule").post(protectDoctor, updateSchedule);
router.route("/getDoctorSchedule").get(protectDoctor, getDoctorSchedule);
router
  .route("/addPatientMedicalHistory")
  .post(
    protectDoctor,
    upload.array("documents", 10),
    updatePatientMedicalHistory
  );
router
  .route("/medicalHistory/:patientId")
  .get(protectDoctor, PatientMedicalHistory);

export default router;
