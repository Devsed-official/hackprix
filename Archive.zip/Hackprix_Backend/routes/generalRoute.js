import express from 'express';
import { getAllCategories, getAllHospital, getAllPatients, getAllTestProviders, getAllTests, getCharityNeedingUsers, getDoctorsBySpecialization, getHospitalById } from '../controllers/generalController.js';
const router = express.Router();

router.route("/allHospitals").get(getAllHospital);
router.route("/getHospitalById/:id").get(getHospitalById);
router.route("/getCharityNeededUsers").get(getCharityNeedingUsers);
router.route("/categories").get(getAllCategories);
router.route("/getDoctorsBySpecialization/:specialization").get(getDoctorsBySpecialization);
router.route("/tests").get(getAllTests);
router.route("/testProviders").get(getAllTestProviders);
router.route("/patients").get(getAllPatients);

export default router;