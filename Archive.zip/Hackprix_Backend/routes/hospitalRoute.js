import express from 'express';
import { Verifycode, addDoctorForHospital, allReportsRequested, changePassword, hostpitalLogin, newPassword, postReport, registerForLab, sendVerifyCode } from '../controllers/hospitalController.js';
import { protectHospital } from '../middleware/middleware.js';
const router = express.Router();

router.route("/login").post(hostpitalLogin);
router.route("/sendVerificationCode").post(sendVerifyCode);
router.route("/verifyCode").post(Verifycode);
router.route("/newPassword").post(protectHospital, newPassword);
router.route("/changePassword").post(protectHospital, changePassword);
router.route("/addDoctor").post(protectHospital, addDoctorForHospital);
router.route("/registerForLab").post(protectHospital, registerForLab);
router.route("/allReportsRequested").get(protectHospital, allReportsRequested);
router.route("/postReport").get(protectHospital, postReport);

export default router;