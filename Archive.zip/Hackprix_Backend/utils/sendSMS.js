import twilio from "twilio"
async function sendSMS(to, body) {
    const client = twilio(process.env.accountSid, process.env.authToken);

    try {
        const message = await client.messages.create({
            body: body,
            from: process.env.twilioPhoneNumber,
            to: to
        });
        console.log(`SMS sent to ${to}: ${message.sid}`);
    } catch (error) {
        console.error('Error sending SMS:', error.message);
    }
}

export default sendSMS;