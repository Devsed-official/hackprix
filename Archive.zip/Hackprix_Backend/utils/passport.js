import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();
import patientModel from "../models/patient.js";

console.log(process.env.GOOGLE_CLIENT_ID,process.env.GOOGLE_CLIENT_SECRET)
//google login and registration
passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: "http://localhost:3001/api/v1/patient/auth/google/callback",
    },
    async (accessToken, refreshToken, profile, cb) => {
      try {
        // console.log(profile)
        // Find or create user based on Google ID
        let user = await patientModel.findOne({ socialId: profile.id });

        if (!user) {
          user = new patientModel({
            name: profile.displayName,
            email: profile.emails[0].value,
            socialId: profile.id,
            gender: profile.gender ? profile.gender : undefined, // Add gender if available
            phone: profile.phone ? profile.phone : undefined, // Add phone if available
            phoneVerified: !!profile.phone, // Set phoneVerified to true if phone is available
          });

          await user.save();
        }

        // Generate JWT token
        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
          expiresIn: "30d",
        });

        // Save the token to the user document
        user.token = token;
        await user.save();

        // Call the callback function with a successful result
        return cb(null, user);
      } catch (error) {
        // Call the callback function with an error
        return cb(error);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  console.log(user, "serialize");
  done(null, user._id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await StudentModel.findById(id);
    done(null, user);
  } catch (error) {
    done(error);
  }
});
