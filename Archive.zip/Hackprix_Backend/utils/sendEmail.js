import { Resend } from 'resend';

const sendEmail = async (email, content, name) =>{
    try {
        const resend = new Resend('re_8GpPR46V_BDo7RFY6rBMjNEWDKnnPPK6A');

        resend.emails.send({
            from: 'zainii@devsed.com',
            to: [email],
            subject: `hello ${name}`,
            html: `<p>${content}</p>`
        });
    }
    catch (err) {
        console.error(err);
    }
}

export default sendEmail;

