import {
    RoomServiceClient,
    EgressClient,
    EncodedFileOutput,
    S3Upload,
    WebhookReceiver,
} from "livekit-server-sdk";

// Function to initialize RoomServiceClient and AccessToken
const initLivekit = async () => {
    const livekit = await import("livekit-server-sdk");
    const RoomServiceClient = new livekit.RoomServiceClient(
        process.env.LIVEKIT_HOST,
        process.env.LIVEKIT_API_KEY,
        process.env.LIVEKIT_API_SECRET
    );
    const AccessToken = livekit.AccessToken;
    return { RoomServiceClient, AccessToken };
};

const createTokenFreeTrial = async (req, res) => {
    try {
        if (req.user) {
            const { slotId } = req.body;
            const roomName = slotId;
            const { AccessToken } = await initLivekit();

            const at = new AccessToken(
                process.env.LIVEKIT_API_KEY,
                process.env.LIVEKIT_API_SECRET,
                {
                    identity: req.user.name,
                    ttl: "90m",
                }
            );

            at.addGrant({
                roomJoin: true,
                room: roomName,
            });

            const token = await at.toJwt();
            res.send(token);
        } else {
            res.status(401).json({ error: "No token" });
        }
    } catch (error) {
        console.error("Error generating token:", error);
        res.status(500).send("Internal Server Error");
    }
};

export {
    createTokenFreeTrial
}