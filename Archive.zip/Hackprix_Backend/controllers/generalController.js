import doctorModel from "../models/doctor.js";
import categoryModel from "../models/doctorCategories.js";
import hospitalModel from "../models/hospital.js";
import patientModel from "../models/patient.js";
import testProvidersModel from "../models/testProviders.js";
import testModel from "../models/tests.js";

const getAllHospital = async (req, res) => {
    try {
        const hospitals = await hospitalModel.find().select(" -password");
        return res.json(hospitals)
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getHospitalById = async (req, res) => {
    try {
        const { id } = req.params;
        const hospital = await hospitalModel.findOne({ _id: id }).select(" -password");
        if (!hospital) {
            return res.status(400).json({ error: "No such hospital found" });
        }
        res.status(200).json(hospital)
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getCharityNeedingUsers = async (req, res) => {
    try {
        const patients = await patientModel.find({ charity: true });
        res.status(200).json(patients)
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getAllCategories = async (req, res) => {
    try {
        const categories = await categoryModel.find();
        res.status(200).json(categories);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getDoctorsBySpecialization = async (req, res) => {
    try {
        const { specialization } = req.params;
        const doctors = await doctorModel.find({ specialization: specialization })
        res.status(200).json({ doctors });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getAllTests = async (req, res) =>{
    try{
        const tests = await testModel.find();
        res.status(200).json(tests);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getAllTestProviders = async (req, res) =>{
    try{
        const testProviders = await testProvidersModel.find().populate("hospital", "name");
        return res.status(200).json(testProviders);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getAllPatients = async (Req, res) =>{
    try{
        const patients = await patientModel.find();
        res.status(200).json(patients);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

export {
    getAllHospital,
    getHospitalById,
    getCharityNeedingUsers,
    getAllCategories,
    getDoctorsBySpecialization,
    getAllTests,
    getAllTestProviders,
    getAllPatients
}