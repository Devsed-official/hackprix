import jwt from "jsonwebtoken"
import patientModel from "../models/patient.js";
import generateOTP from "../utils/generateOtp.js";
import sendSMS from "../utils/sendSMS.js";
import sendEmail from "../utils/sendEmail.js";
import medicalHistoryModel from "../models/medicalHistory.js";
import insuranceModel from "../models/insurances.js";
import talkWith from "../utils/talkWith.js"
import bookedSlotsModel from "../models/bookedSlots.js";
import doctorScheduleModel from "../models/doctorSchedule.js";
import bookedSlotsStudentModel from "../models/bookedSlotsPatient.js";
// import { json } from "express";
import testProvidersModel from "../models/testProviders.js";
import bookedReportSlotModel from "../models/bookedReportSlots.js";
import reportModel from "../models/reports.js";
import doctorModel from "../models/doctor.js";
import passport from "passport"
// import talkWith2 from "../utils/talkWith2.js";

const getPatient = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(400).json({ error: "Invalid Token" });
        }
        return res.status(200).json({
            _id: req.user._id,
            email: req.user.email,
            name: req.user.name,
            token: req.user.token,
            phone: req.user.phone,
            gender: req.user.gender,
            dob: req.user.dob,
            alchohol: req.user.alchohol,
            no_of_meals: req.user.no_of_meals,
            diet: req.user.diet,
            smoking: req.user.smoking,
            exercise: req.user.exercise
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const PatientRegistration = async (req, res) => {
    try {
        const { email, password, name } = req.body;

        const patient = await patientModel.findOne({ email: email });
        if (patient) {
            return res.status(400).json({ error: "Email already exists" });
        }

        const newPatient = new patientModel({
            email: email,
            name: name,
        });
        await newPatient.save();

        const token = jwt.sign({ id: newPatient.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        newPatient.token = token;

        const encryptedPassword = await newPatient.encryptPassword(password);
        newPatient.password = encryptedPassword;

        await newPatient.save();

        res.status(201).json({
            _id: newPatient._id,
            email: newPatient.email,
            name: newPatient.name,
            token: newPatient.token,
            // phone: newPatient.phone,
            // gender: newPatient.gender,
            // dob: newPatient.dob,
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const PatientLogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        const student = await patientModel.findOne({ email: email });
        if (!student) {
            return res.status(400).json({ error: "Email dose not exists" });
        }

        if (student && student.socialId) {
            return res.status(400).json({ error: "Please login using Google" });
        }

        const validate = await student.validatePassword(password);
        if (!validate) {
            return res.status(401).json({ error: "Password incorrect" });
        }

        const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        student.token = token;
        await student.save();

        res.status(201).json({
            _id: student._id,
            email: student.email,
            name: student.name,
            token: student.token,
            phone: student.phone,
            gender: student.gender,
            dob: student.dob,
            alchohol: student.alchohol,
            no_of_meals: student.no_of_meals,
            diet: student.diet,
            smoking: student.smoking,
            exercise: student.exercise
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const updatePatientDetails = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(404).json({ error: "Invalid Token" });
        }
        const { name, phone, email, gender, dob, designation } = req.body;

        const patient = await patientModel.findOne({ _id: req.user._id });

        patient.name = name || patient.name;
        patient.phone = phone || patient.phone;
        patient.email = email || patient.email;
        patient.dob = dob || patient.dob;
        patient.gender = gender || patient.gender;
        patient.designation = designation || patient.designation;

        await patient.save();

        res.status(201).json({
            _id: patient._id,
            email: patient.email,
            name: patient.name,
            token: patient.token,
            phone: patient.phone,
            gender: patient.gender,
            dob: patient.dob,
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const sendVerification = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(404).json({ error: "Invalid Token" });
        }
        const user = req.user._id;
        // console.log(user)
        const userExists = await patientModel.findById(user);
        if (user) {
            const { phone } = req.body;
            const existingUserWithPhone = await patientModel.findOne({ phone });

            if (
                existingUserWithPhone &&
                existingUserWithPhone._id.toString() !== user
            ) {
                // Another user already has this phone number
                return res.status(400).json({
                    message:
                        "Duplicate -- Phone number is already in use by another user.",
                });
            }
            userExists.otp = generateOTP(6);
            await userExists.save();

            await sendSMS(
                phone,
                `Your OTP for authentication is: ${userExists.otp}`
            );

            res.status(200).json({ message: "otp sent succesfully" });
        } else {
            res.status(404).json({ message: "User not found" });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
};

const verifyPhone = async (req, res) => {
    try {
        const user1 = req.user;
        const { otp, phone } = req.body;
        if (user1) {
            const user = await patientModel.findById(user1._id);
            if (user.otp === otp) {
                user.phone = phone;
                await user.save();

                res.status(200).json(user);
            } else {
                res.status(400).json({ error: "Otp is incorrect" });
            }
        } else {
            res.status(404).json({ message: "user not found" });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
};

const sendVerifyCode = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await patientModel.findOne({ email: email });
        if (!user) {
            return res.status(400).json({ error: "No such email found" });
        }

        if (user.socialId) {
            return res.status(400).json({ message: "Please Login using Google" });
        }

        user.verification = generateOTP(6);
        await user.save();

        if (user.email) {
            // await sendSMS(
            //   user.phone,
            //   `Your verification code is: ${user.verification}`
            // );
            await sendEmail(user.email, `Your verification code for changing the password is ${user.verification}`, user.name);
        } else {
            return res
                .status(304)
                .json({ message: "Phone Number not verified. Please register again." });
        }

        res.status(200).json({
            message: "Verification code sent succesfully",
            phone: user.phone,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const Verifycode = async (req, res) => {
    try {
        const { email, code } = req.body;
        const user = await patientModel.findOne({ email: email });
        if (!user) {
            return res.status(400).json({ error: "No such email found" });
        }

        if (user.verification == code) {
            return res.status(200).json({ token: user.token });
        } else {
            res.status(400).json({ error: "Invalid code" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const newPassword = async (req, res) => {
    try {
        if (req.user) {
            const { password } = req.body;
            const user = await patientModel.findOne({ _id: req.user._id });
            user.password = await user.encryptPassword(password);

            await user.save();
            res.status(200).json({ message: "New Password set successfully." });
        } else {
            res.status(400).json({ error: "Unauthorized" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const changePassword = async (req, res) => {
    const userEmail = req.user.email;

    try {
        const user = await patientModel.findOne({ email: userEmail });

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        const { oldPassword, newPassword } = req.body;
        const isPasswordValid = await user.validatePassword(oldPassword);

        if (!isPasswordValid) {
            return res.status(401).json({ message: "Invalid old password" });
        }

        user.password = await user.encryptPassword(newPassword);
        await user.save();

        await sendEmail(user.email, "Password has been changed successfully", user.name);
        res.status(200).json({ message: "Password changed successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const updateHabits = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(400).json({ error: "Invalid token" });
        }
        const { smoking, alchohol, diet, no_of_meals, exercise } = req.body;
        const user = await patientModel.findOne({ _id: req.user._id });
        user.smoking = smoking;
        user.alchohol = alchohol;
        user.diet = diet;
        user.no_of_meals = no_of_meals;
        user.exercise = exercise

        await user.save();
        return res.status(200).json({
            _id: user._id,
            email: user.email,
            name: user.name,
            token: user.token,
            phone: user.phone,
            gender: user.gender,
            dob: user.dob,
            alchohol: user.alchohol,
            no_of_meals: user.no_of_meals,
            diet: user.diet,
            smoking: user.smoking,
            exercise: user.exercise
        })
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const askForCharityOrNot = async (req, res) => {
    try {
        if (!req.user) {
            res.status(400).json({ error: "Invalid token" })
        }
        const { bankDetails } = req.body;
        const patient = await patientModel.findOne({ _id: req.user._id });
        if (!patient.charity && !patient.bankDetails) {
            return res.status(400).json({ error: "Please provide bank details" });
        }
        if (patient.charity) {
            patient.charity = false;
        }
        else {
            patient.charity = true;
            patient.bankDetails = bankDetails;
        }
        await patient.save();

        res.status(200).json({ message: `Updated charity to ${patient.charity}` });
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const addMedicalHistory = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(400).json({ error: "Invalid Token" });
        }
        const { description, doctor, hospital, Issue, Remark, critical } = req.query;
        let criticalArray = null;
        if (critical) {
            criticalArray = JSON.parse(critical);
        }
        const files = req.files || [];
        if (!req.files && !description) {
            return res.status(400).json({ error: "Please provide files or a description" });
        }

        // Validate if patient exists
        const patient = await patientModel.findById(req.user._id);
        if (!patient) {
            return res.status(404).json({ error: "Patient not found" });
        }

        // Create docs array from uploaded files
        const docs = files.map(file => ({
            title: file.originalname,
            url: `/Documents/${file.filename}`
        }));

        let medicalHistory = await medicalHistoryModel.findOne({
            patient: req.user._id
        })
        if (!medicalHistory) {
            medicalHistory = new medicalHistoryModel({
                patient: req.user._id,
                history: [
                    {
                        date: new Date(),
                        description: description,
                        docs: docs,
                        doctor: doctor,
                        hospital: hospital,
                        Issue: Issue,
                        Remark: Remark,
                        critical_details: criticalArray || []
                    }
                ]
            })
        }
        else {
            medicalHistory.history.push({
                date: new Date(),
                description: description,
                docs: docs,
                doctor: doctor,
                hospital: hospital,
                Issue: Issue,
                Remark: Remark,
                critical_details: criticalArray || []
            })
        }
        await medicalHistory.save()

        return res.status(200).json({ message: "Added successfully" })
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const addInsurances = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(403).json({ error: "Invalid Token" });
        }
        const { insuranceCompany, insuranceNumber, package1, cost, limit, remainingLimit, expiry } = req.body;
        let insurance = await insuranceModel.findOne({ patient: req.user._id });
        if (!insurance) {
            insurance = new insuranceModel({
                patient: req.user._id,
                history: [
                    {
                        insuranceCompany: insuranceCompany,
                        insuranceNumber: insuranceNumber,
                        package: package1,
                        cost: cost,
                        limit: limit,
                        remainingLimit: remainingLimit,
                        expiry: expiry
                    }
                ]
            })
        }
        else {
            insurance.history.push({
                insuranceCompany: insuranceCompany,
                insuranceNumber: insuranceNumber,
                package: cost,
                limit: limit,
                remainingLimit: remainingLimit,
                expiry: expiry
            })
        }

        await insurance.save();
        res.status(200).json({ message: "Added Successfully" });
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const talkWithAi = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(200).json({ error: "Invalid token" });
        }
        const { question } = req.body;
        if (!question) {
            return res.status(200).josn({ error: "Please ask a question" })
        }
        const data = await talkWith(question);
        return res.status(200).send(data);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const bookASlot = async (req, res) => {
    try {
        const { slotId, date } = req.body;
        const doctorSchedule = await doctorScheduleModel.findOne({
            "sessions.slots._id": slotId,
        });
        if (!doctorSchedule) {
            return res.status(404).json({ error: "Teacher Schedule not found" });
        }
        let wantedslot = null;
        doctorSchedule.sessions.forEach((session) => {
            session.slots.forEach((slot) => {
                if (slot._id.toString() === slotId.toString()) {
                    wantedslot = slot;
                }
            });
        });
        const exists = await bookedSlotsModel.findOne({
            slots: {
                $elemMatch: {
                    date: date,
                    "slot.start_time": wantedslot.start_time
                }
            }
        });
        if (exists) {
            return res.status(200).json({ error: "Slots Already Booked" });
        }
        else {
            let newSchedule = await bookedSlotsModel.findOne({ doctor: doctorSchedule.doctor });
            if (newSchedule) {
                newSchedule.slots.push({
                    date: date,
                    slot: {
                        name: wantedslot.name,
                        start_time: wantedslot.start_time,
                        patient: req.user._id,
                        slotId: wantedslot._id
                    }
                })
            }
            else {
                newSchedule = new bookedSlotsModel({
                    doctor: doctorSchedule.doctor,
                    slots: [{
                        date: date,
                        slot: {
                            name: wantedslot.name,
                            start_time: wantedslot.start_time,
                            patient: req.user._id,
                            slotId: wantedslot._id
                        }
                    }]
                })
            }
            await newSchedule.save();
            let studentBooked = await bookedSlotsStudentModel.findOne({ patient: req.user._id });
            if (studentBooked) {
                studentBooked.slots.push({
                    date: date,
                    slot: {
                        name: wantedslot.name,
                        start_time: wantedslot.start_time,
                        doctor: doctorSchedule.doctor,
                        slotId: slotId
                    }
                })
            }
            else {
                studentBooked = new bookedSlotsStudentModel({
                    patient: req.user._id,
                    slots: [{
                        date: date,
                        slot: {
                            name: wantedslot.name,
                            start_time: wantedslot.start_time,
                            doctor: doctorSchedule.doctor,
                            slotId: slotId
                        }
                    }]
                })
            }
            await studentBooked.save()
        }
        res.status(200).json({ message: "Slot booked successfully" })
    } catch (e) {
        console.error(e);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const getFilteredTestProviders = async (req, res) => {
    try {
        const { tests } = req.body;

        // Validate the input
        if (!Array.isArray(tests) || tests.length === 0) {
            return res.status(400).json({ message: "Invalid input. 'tests' should be a non-empty array." });
        }

        // Find test providers that offer all specified tests
        const testProviders = await testProvidersModel.find({
            testAvailable: { $all: tests }
        }).populate("hospital", "name").select(" -testAvailable");

        res.status(200).json(testProviders);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const bookTests = async (req, res) => {
    try {
        const testId = generateOTP(10);
        const { date, time, testProviderId, tests } = req.body;
        let bookTests = await bookedReportSlotModel.findOne({
            hospital: testProviderId
        })
        const find = await testProvidersModel.findOne({
            _id: testProviderId
        })
        if (find) {
            bookTests = await bookedReportSlotModel.findOne({
                name: "Hackprix Labs"
            })
        }
        if (!bookTests) {
            return res.status(400).json({ error: "No such test provider" })
        }

        const exists = bookTests.slots.find((slot) => {
            return slot.date == date && slot.time == time
        })
        if (exists) {
            return res.status(200).json({ error: "No Free Slot on this time, please choose another" });
        }
        bookTests.slots.push({
            date: date,
            time: time,
            patient: req.user._id,
            tests: tests,
            testId: testId
        })
        await bookTests.save();

        let reports = await reportModel.findOne({
            patient: req.user._id
        })
        if (!reports) {
            reports = new reportModel({
                patient: req.user._id,
                history: [
                    {
                        testId: testId,
                        title: tests.join(", ")
                    }
                ]
            })
        }
        else {
            reports.history.push({
                testId: testId,
                title: tests.join(", ")
            })
        }
        await reports.save();

        return res.status(200).json({ message: "Test Booked Succesfully" })
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const dashboardHit = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(400).json({ error: "Invalid Token" });
        }
        const bookedSlot = await bookedSlotsStudentModel.findOne({ patient: req.user._id }).populate("slots.slot.doctor", "name");
        const lastSlot = bookedSlot.slots[bookedSlot.slots.length - 1];

        const healthHistory = await medicalHistoryModel.findOne({ patient: req.user._id });
        const history = healthHistory.history;

        const insurances = await insuranceModel.findOne({ patient: req.user._id }).select("-eligibleHospitals");
        const insurancesHistory = insurances.history[insurances.history.length - 1];

        const reports = await reportModel.findOne({ patient: req.user._id });
        const reportHistory = reports.history;

        // const number = await talkWith2(JSON.stringify(reportHistory));

        return res.status(200).json({ lastSlot, history, insurancesHistory, reportHistory, number: 5 })

    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getAllMedicalHistory = async (req, res) => {
    try {
        const healthHistory = await medicalHistoryModel.findOne({ patient: req.user._id });
        if (!healthHistory) {
            return res.status(400).json({ error: "Invalid Token" });
        }
        const history = healthHistory.history;
        res.status(200).json(history);

    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getHistoryById = async (req, res) => {
    try {
        const { id } = req.params;
        const medicalhistory = await medicalHistoryModel.findOne({ "history._id": id });
        if (!medicalhistory) {
            return res.status(400).json({ error: "Invalid token" });
        }
        let object = null;
        medicalhistory.history.forEach((obj) => {
            if (obj._id.toString() == id.toString()) {
                object = obj;
            }
        })
        res.status(200).json(object);

    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getDoctorSchedule = async (req, res) => {
    try {
        const { doctorId } = req.params;
        const doctorSchedule = await doctorScheduleModel.findOne({ doctor: doctorId });
        if (!doctorSchedule) {
            return res.status(400).json({ error: "No Schedule for doctor" });
        }
        const booked = await bookedSlotsModel.findOne({ doctor: doctorId });
        return res.status(200).json({ schedule: doctorSchedule.sessions, busySlots: booked.slots })
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getAllAppointments = async (req, res) => {
    try {
        if (!req.user._id) {
            return res.status(200).json({ error: "Invalid Token" })
        }
        const bookedSlot = await bookedSlotsStudentModel.findOne({ patient: req.user._id }).populate("slots.slot.doctor", "name specialization");;
        if (!bookedSlot) {
            return res.status(200).json([]);
        }
        return res.status(200).json(bookedSlot.slots);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getAllDoctors = async (req, res) => {
    try {
        const doctors = await doctorModel.find().populate("hospital", "name");
        res.status(200).json(doctors)
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getAllTests = async (req, res) => {
    try {
        const reports = await reportModel.findOne({ patient: req.user._id });
        if (!reports) {
            return res.status(200).json([])
        }
        const reportHistory = reports.history;
        res.status(200).json(reportHistory);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const getTestById = async (req, res) => {
    try {
        const { id } = req.params;
        const medicalhistory = await reportModel.findOne({ "history._id": id });
        if (!medicalhistory) {
            return res.status(400).json({ error: "No Medical record" });
        }
        let object = null;
        medicalhistory.history.forEach((obj) => {
            if (obj._id.toString() == id.toString()) {
                object = obj;
            }
        })
        res.status(200).json(object);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: "Internal Server Error" });
    }
}


//Login and Register Google
const googleLoginReg = passport.authenticate("google", {
    scope: [
        "profile",
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/userinfo.profile",
        "https://www.googleapis.com/auth/user.gender.read",
        "https://www.googleapis.com/auth/user.phonenumbers.read",
    ],
    include_granted_scopes: true,
});
//Login and Register Google Callback
const callbackGoogle = passport.authenticate("google", {
    failureRedirect: "/login-failure",
});


// Middleware function for handling the callback
const handleAllCallback = (req, res) => {
    // If authentication failed, redirect to the failure route
    if (!req.user) {
        return res.redirect("/login-failure");
    }
    res.redirect(process.env.Success_Url_Login + req.user.token);
};


export {
    PatientRegistration,
    PatientLogin,
    updatePatientDetails,
    sendVerification,
    verifyPhone,
    sendVerifyCode,
    Verifycode,
    newPassword,
    changePassword,
    updateHabits,
    askForCharityOrNot,
    addMedicalHistory,
    addInsurances,
    talkWithAi,
    bookASlot,
    getFilteredTestProviders,
    bookTests,
    dashboardHit,
    getAllMedicalHistory,
    getHistoryById,
    getDoctorSchedule,
    getPatient,
    getAllAppointments,
    getAllDoctors,
    getAllTests,
    getTestById,
    googleLoginReg,
    callbackGoogle,
    handleAllCallback
}