import hospitalModel from "../models/hospital.js";
import jwt from "jsonwebtoken";
import generateOTP from "../utils/generateOtp.js";
import sendEmail from "../utils/sendEmail.js";
import doctorModel from "../models/doctor.js";
import testProvidersModel from "../models/testProviders.js";
import bookedReportSlotModel from "../models/bookedReportSlots.js";
import reportModel from "../models/reports.js";

const hostpitalLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await hospitalModel.findOne({ email });
        if (!user) {
            return res.status(401).json({ error: "Invalid Credentials" });
        }

        const isPasswordValid = await user.validatePassword(password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: "Invalid Credentials" });
        }

        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        user.token = token;
        await user.save();

        res
            .status(200)
            .json(user);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

const sendVerifyCode = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await hospitalModel.findOne({ email: email });
        if (!user) {
            return res.status(400).json({ error: "No such email found" });
        }

        if (user.socialId) {
            return res.status(400).json({ message: "Please Login using Google" });
        }

        user.verification = generateOTP(6);
        await user.save();

        if (user.email) {
            await sendEmail(user.email, `Your verification code for changing the password is ${user.verification}`, user.name);
        } else {
            return res
                .status(304)
                .json({ message: "Phone Number not verified. Please register again." });
        }

        res.status(200).json({
            message: "Verification code sent succesfully",
            phone: user.phone,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const Verifycode = async (req, res) => {
    try {
        const { email, code } = req.body;
        const user = await hospitalModel.findOne({ email: email });
        if (!user) {
            return res.status(400).json({ error: "No such email found" });
        }

        if (user.verification == code) {
            return res.status(200).json({ token: user.token });
        } else {
            res.status(400).json({ error: "Invalid code" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const newPassword = async (req, res) => {
    try {
        if (req.user) {
            const { password } = req.body;
            const user = await hospitalModel.findOne({ _id: req.user._id });
            user.password = await user.encryptPassword(password);

            await user.save();
            res.status(200).json({ message: "New Password set successfully." });
        } else {
            res.status(400).json({ error: "Unauthorized" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const changePassword = async (req, res) => {
    const userEmail = req.user.email;

    try {
        const user = await hospitalModel.findOne({ email: userEmail });

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        const { oldPassword, newPassword } = req.body;
        const isPasswordValid = await user.validatePassword(oldPassword);

        if (!isPasswordValid) {
            return res.status(401).json({ message: "Invalid old password" });
        }

        user.password = await user.encryptPassword(newPassword);
        await user.save();

        await sendEmail(user.email, "Password has been changed successfully", user.name);
        res.status(200).json({ message: "Password changed successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
};

const addDoctorForHospital = async (req, res) => {
    try {
        if (!req.user) {
            return res.status(403).json({ error: "Invalid token" });
        }
        const { email, password, name, specialization } = req.body;
        const doctor = await doctorModel.findOne({ email: email });
        if (doctor) {
            return res.status(400).json({ error: "Email already exists" });
        }

        const newDoctor = new doctorModel({
            email: email,
            name: name,
        });
        await newDoctor.save();

        const token = jwt.sign({ id: newDoctor.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        newDoctor.token = token;

        const encryptedPassword = await newDoctor.encryptPassword(password);
        newDoctor.password = encryptedPassword;
        newDoctor.hospital = req.user._id;
        newDoctor.specialization = specialization;

        await newDoctor.save();

        const hospital = await hospitalModel.findOne({ _id: req.user._id });
        const doctorId = newDoctor._id
        hospital.doctors.push(doctorId);
        await hospital.save();

        res.status(200).json({ message: "Doctor saved successfully"})
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const registerForLab = async (req, res) =>{
    try{
        if(!req.user){
            return res.send(400).json({ error: "Invalid Token" });
        }
        const { testAvailable } = req.body;
        const testProvider = new testProvidersModel({
            hospital: req.user._id,
            testAvailable: testAvailable
        })
        await testProvider.save();

        const bookedSlots = new bookedReportSlotModel({
            hospital: req.user._id,
        })
        await bookedSlots.save()
        res.status(200).json({ message: "Added succesfully"})
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const allReportsRequested = async (req, res) =>{
    try{
        const bookedReports = await bookedReportSlotModel.findOne({
            hospital: req.user._id
        })
        if(!bookedReports){
            return res.status(200).json([]);
        }
        return res.status(200).json(bookedReports.slots)
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

const postReport = async (req, res) => {
    try{
        const { testId, description, parameters  } = req.body;
        const reports = await reportModel.findOne({ "history.testId": testId });
        let wantedReport = null;
        if(!reports){
            return res.status(400).json({ error: "No such report found"})
        }

        reports.history.forEach((obj1)=>{
            if(obj1.testId == testId){
                wantedReport = obj1
            }
        })
        console.log(wantedReport);
        wantedReport.date = new Date();
        wantedReport.description = description;
        wantedReport.parameters = parameters;

        await reports.save();

        const updateResult = await bookedReportSlotModel.updateOne(
            { "slots.testId": testId },
            { $pull: { slots: { testId: testId } } }
        );

        return res.status(200).json({ message: "Added successfully"})
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

export {
    hostpitalLogin,
    sendVerifyCode,
    Verifycode,
    newPassword,
    changePassword,
    addDoctorForHospital,
    registerForLab,
    allReportsRequested,
    postReport
}