import jwt from "jsonwebtoken";
import doctorModel from "../models/doctor.js";
import generateOTP from "../utils/generateOtp.js";
import sendSMS from "../utils/sendSMS.js";
import sendEmail from "../utils/sendEmail.js";
import doctorScheduleModel from "../models/doctorSchedule.js";
import medicalHistoryModel from "../models/medicalHistory.js";
import patientModel from "../models/patient.js";
import bookedSlotsModel from "../models/bookedSlots.js";
import path from "path";

const getDoctor = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(400).json({ error: "Invalid Token" });
    }
    return res.status(200).json({
      _id: req.user._id,
      email: req.user.email,
      name: req.user.name,
      token: req.user.token,
      phone: req.user.phone,
      gender: req.user.gender,
      dob: req.user.dob,
      openToSessions: req.user.openToSessions,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const DoctorRegistration = async (req, res) => {
  try {
    const { email, password, name } = req.body;

    const doctor = await doctorModel.findOne({ email: email });
    if (doctor) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const newDoctor = new doctorModel({
      email: email,
      name: name,
    });
    await newDoctor.save();

    const token = jwt.sign({ id: newDoctor.id }, process.env.JWT_SECRET, {
      expiresIn: "30d",
    });
    newDoctor.token = token;

    const encryptedPassword = await newDoctor.encryptPassword(password);
    newDoctor.password = encryptedPassword;

    await newDoctor.save();

    res.status(201).json({
      _id: newDoctor._id,
      email: newDoctor.email,
      name: newDoctor.name,
      token: newDoctor.token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const DoctorLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    const doctor = await doctorModel.findOne({ email: email });
    if (!doctor) {
      return res.status(400).json({ error: "Email does not exist" });
    }

    if (doctor && doctor.socialId) {
      return res.status(400).json({ error: "Please login using Google" });
    }

    const validate = await doctor.validatePassword(password);
    if (!validate) {
      return res.status(401).json({ error: "Password incorrect" });
    }

    const token = jwt.sign({ id: doctor._id }, process.env.JWT_SECRET, {
      expiresIn: "30d",
    });
    doctor.token = token;
    await doctor.save();

    res.status(201).json({
      _id: doctor._id,
      email: doctor.email,
      name: doctor.name,
      token: doctor.token,
      phone: doctor.phone,
      gender: doctor.gender,
      dob: doctor.dob,
      openToSessions: doctor.openToSessions,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateDoctorDetails = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(404).json({ error: "Invalid Token" });
    }
    const {
      name,
      phone,
      email,
      gender,
      dob,
      designation,
      specialization,
      openToSessions,
    } = req.body;

    const doctor = await doctorModel.findOne({ _id: req.user._id });

    doctor.name = name || doctor.name;
    doctor.phone = phone || doctor.phone;
    doctor.email = email || doctor.email;
    doctor.dob = dob || doctor.dob;
    doctor.gender = gender || doctor.gender;
    doctor.designation = designation || doctor.designation;
    doctor.specialization = specialization || doctor.specialization;
    doctor.openToSessions = openToSessions || doctor.openToSessions;

    await doctor.save();

    res.status(201).json({
      _id: doctor._id,
      email: doctor.email,
      name: doctor.name,
      token: doctor.token,
      phone: doctor.phone,
      gender: doctor.gender,
      dob: doctor.dob,
      openToSessions: doctor.openToSessions,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const sendVerification = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(404).json({ error: "Invalid Token" });
    }
    const user = req.user._id;
    const userExists = await doctorModel.findById(user);
    if (user) {
      const { phone } = req.body;
      const existingUserWithPhone = await doctorModel.findOne({ phone });

      if (
        existingUserWithPhone &&
        existingUserWithPhone._id.toString() !== user
      ) {
        return res.status(400).json({
          message:
            "Duplicate -- Phone number is already in use by another user.",
        });
      }
      userExists.otp = generateOTP(6);
      await userExists.save();

      await sendSMS(phone, `Your OTP for authentication is: ${userExists.otp}`);

      res.status(200).json({ message: "OTP sent successfully" });
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const verifyPhone = async (req, res) => {
  try {
    const user1 = req.user;
    const { otp, phone } = req.body;
    if (user1) {
      const user = await doctorModel.findById(user1._id);
      if (user.otp === otp) {
        user.phone = phone;
        await user.save();

        res.status(200).json(user);
      } else {
        res.status(400).json({ error: "OTP is incorrect" });
      }
    } else {
      res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const sendVerifyCode = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await doctorModel.findOne({ email: email });
    if (!user) {
      return res.status(400).json({ error: "No such email found" });
    }

    if (user.socialId) {
      return res.status(400).json({ message: "Please Login using Google" });
    }

    user.verification = generateOTP(6);
    await user.save();

    if (user.email) {
      await sendEmail(
        user.email,
        `Your verification code for changing the password is ${user.verification}`,
        user.name
      );
    } else {
      return res
        .status(304)
        .json({ message: "Phone Number not verified. Please register again." });
    }

    res.status(200).json({
      message: "Verification code sent successfully",
      phone: user.phone,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const Verifycode = async (req, res) => {
  try {
    const { email, code } = req.body;
    const user = await doctorModel.findOne({ email: email });
    if (!user) {
      return res.status(400).json({ error: "No such email found" });
    }

    if (user.verification == code) {
      return res.status(200).json({ token: user.token });
    } else {
      res.status(400).json({ error: "Invalid code" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const newPassword = async (req, res) => {
  try {
    if (req.user) {
      const { password } = req.body;
      const user = await doctorModel.findOne({ _id: req.user._id });
      user.password = await user.encryptPassword(password);

      await user.save();
      res.status(200).json({ message: "New Password set successfully." });
    } else {
      res.status(400).json({ error: "Unauthorized" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const changePassword = async (req, res) => {
  const userEmail = req.user.email;

  try {
    const user = await doctorModel.findOne({ email: userEmail });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const { oldPassword, newPassword } = req.body;
    const isPasswordValid = await user.validatePassword(oldPassword);

    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid old password" });
    }

    user.password = await user.encryptPassword(newPassword);
    await user.save();

    await sendEmail(
      user.email,
      "Password has been changed successfully",
      user.name
    );
    res.status(200).json({ message: "Password changed successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const createScheule = async (req, res) => {
  try {
    const { schedule } = req.body;
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const doctorSchedule = async (req, res) => {
  try {
    if (req.user) {
      const { schedule } = req.body;
      const doctor = await doctorModel.findOne({ _id: req.user._id });
      if (!doctor.openToSessions) {
        return res
          .status(400)
          .json({ error: "Doctor not availale for schedule" });
      }
      const doctorSchedule = await doctorScheduleModel.findOne({
        doctor: doctor._id,
      });
      if (doctorSchedule) {
        return res.status(400).json({ error: "Schedule already exists" });
      }

      let totalFreeSlots = 0;

      schedule.forEach((day) => {
        const { break_required, time_slot } = day;
        const startTime = new Date(`January 1, 1970 ${time_slot.start_time}`);
        const endTime = new Date(`January 1, 1970 ${time_slot.end_time}`);
        const slots = [];

        // Calculate the number of hours available
        const hoursAvailable = (endTime - startTime) / (1000 * 60 * 60);
        const numSlots = break_required ? hoursAvailable - 1 : hoursAvailable;

        totalFreeSlots += numSlots;

        // Generate slots based on the start time and break required flag
        for (let i = 1; i <= numSlots; i++) {
          const slotStartTime = new Date(
            startTime.getTime() + (i - 1) * (60 * 60 * 1000)
          );
          const slotEndTime = new Date(
            startTime.getTime() + i * (60 * 60 * 1000)
          );
          slots.push({
            name: `Session ${i}`,
            start_time: slotStartTime.toTimeString().slice(0, 5),
            end_time: slotEndTime.toTimeString().slice(0, 5),
          });
        }

        // Update the slots array in the day object
        day.slots = slots;
      });

      const NewSchedule = new doctorScheduleModel({
        doctor: doctor._id,
        sessions: schedule,
      });

      await NewSchedule.save();

      res.status(200).json({ message: "Schedule Created Succesfully" });
    } else {
      return res.status(401).json({ error: "No token" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updateScheduleTeacher = async (updateSchedule, doctorId) => {
  try {
    let responseMessage = "";
    const existingSchedule = await doctorScheduleModel.findOne({
      doctor: doctorId,
    });
    if (!existingSchedule) {
      responseMessage = "No Existing Schedule Found";
      return responseMessage;
    }

    for (const obj of updateSchedule) {
      let found = false;

      for (const obj1 of existingSchedule.sessions) {
        if (obj1.day === obj.day) {
          found = true;

          let exists = false;
          for (const slot of obj1.slots) {
            if (slot.patient) {
              exists = true;
              break;
            }
          }

          if (exists) {
            if (obj.time_slot.end_time <= obj1.time_slot.end_time) {
              responseMessage += `/n could not update ${obj.day} because of existing slots`;
              break; // or continue, based on your requirements
            } else {
              const slots = [];
              const startTime = new Date(
                `January 1, 1970 ${obj1.time_slot.end_time}`
              );
              const endTime = new Date(
                `January 1, 1970 ${obj.time_slot.end_time}`
              );

              const hoursAvailable = (endTime - startTime) / (1000 * 60 * 60);

              const daySlots = [];
              for (let i = 1; i <= hoursAvailable; i++) {
                const slotStartTime = new Date(
                  startTime.getTime() + (i - 1) * (60 * 60 * 1000)
                );
                const slotEndTime = new Date(
                  startTime.getTime() + i * (60 * 60 * 1000)
                );
                daySlots.push({
                  start_time: slotStartTime.toTimeString().slice(0, 5),
                  end_time: slotEndTime.toTimeString().slice(0, 5),
                });
              }

              slots.push(...daySlots);

              let dayfind = existingSchedule.sessions.find(
                (sess) => sess.day === obj.day
              );
              dayfind.time_slot.end_time = obj.time_slot.end_time;
              dayfind.slots.push(...slots);
              responseMessage += `/n Updated ${obj.day} in schedule and added more slots`;
              await existingSchedule.save();
            }
          } else {
            const slots = [];
            const { time_slot } = obj;
            const startTime = new Date(
              `January 1, 1970 ${time_slot.start_time}`
            );
            const endTime = new Date(`January 1, 1970 ${time_slot.end_time}`);

            const hoursAvailable = (endTime - startTime) / (1000 * 60 * 60);

            const daySlots = [];
            for (let i = 1; i <= hoursAvailable; i++) {
              const slotStartTime = new Date(
                startTime.getTime() + (i - 1) * (60 * 60 * 1000)
              );
              const slotEndTime = new Date(
                startTime.getTime() + i * (60 * 60 * 1000)
              );
              daySlots.push({
                start_time: slotStartTime.toTimeString().slice(0, 5),
                end_time: slotEndTime.toTimeString().slice(0, 5),
              });
            }

            slots.push(...daySlots);

            let dayfind = existingSchedule.sessions.find(
              (sess) => sess.day === obj.day
            );
            dayfind.time_slot = obj.time_slot;
            dayfind.slots = slots;
            responseMessage += `/n Updated ${obj.day} in schedule`;
            await existingSchedule.save();
          }
        }
      }

      if (!found) {
        const slots = [];
        const { time_slot } = obj;
        const startTime = new Date(`January 1, 1970 ${time_slot.start_time}`);
        const endTime = new Date(`January 1, 1970 ${time_slot.end_time}`);

        const hoursAvailable = (endTime - startTime) / (1000 * 60 * 60);

        const daySlots = [];
        for (let i = 1; i <= hoursAvailable; i++) {
          const slotStartTime = new Date(
            startTime.getTime() + (i - 1) * (60 * 60 * 1000)
          );
          const slotEndTime = new Date(
            startTime.getTime() + i * (60 * 60 * 1000)
          );
          daySlots.push({
            start_time: slotStartTime.toTimeString().slice(0, 5),
            end_time: slotEndTime.toTimeString().slice(0, 5),
          });
        }

        slots.push(...daySlots);

        existingSchedule.sessions.push({
          day: obj.day,
          time_slot: obj.time_slot,
          slots: slots,
        });
        await existingSchedule.save();
        responseMessage += `/n Added ${obj.day} in schedule`;
      }
    }

    return responseMessage;
  } catch (err) {
    console.log(err);
  }
};

const getDoctorSchedule = async (req, res) => {
  console.log(req.user);
  try {
    const doctorSchedule = await doctorScheduleModel.findOne({
      doctor: req.user._id,
    });
    if (!doctorSchedule) {
      return res.status(400).json({ error: "No Schedule for doctor" });
    }
    const booked = await bookedSlotsModel
      .findOne({ doctor: req.user._id })
      .populate("slots.slot.patient");
    return res
      .status(200)
      .json({ schedule: doctorSchedule.sessions, busySlots: booked.slots });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const updateSchedule = async (req, res) => {
  try {
    if (req.user) {
      const { schedule } = req.body;
      const data = await updateScheduleTeacher(schedule, req.user._id);

      return res.status(200).send(data);
    } else {
      return res.status(400).json({ error: "No token" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const updatePatientMedicalHistory = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(400).json({ error: "Invalid Token" });
    }
    const { description, Issue, Remark, critical, patientId } = req.query;
    let criticalArray = null;
    if (critical) {
      criticalArray = JSON.parse(critical);
    }
    const files = req.files || [];
    if (!req.files && !description) {
      return res
        .status(400)
        .json({ error: "Please provide files or a description" });
    }

    // Validate if patient exists
    const patient = await patientModel.findById(patientId);
    if (!patient) {
      return res.status(404).json({ error: "Patient not found" });
    }

    // Create docs array from uploaded files
    const docs = files.map((file) => ({
      title: file.originalname,
      url: `/Documents/${file.filename}`,
    }));

    let medicalHistory = await medicalHistoryModel.findOne({
      patient: patientId,
    });
    if (!medicalHistory) {
      medicalHistory = new medicalHistoryModel({
        patient: patientId,
        history: [
          {
            date: new Date(),
            description: description,
            docs: docs,
            doctor: req.user.name,
            hospital: req.user.hospital,
            Issue: Issue,
            Remark: Remark,
            critical_details: criticalArray || [],
          },
        ],
      });
    } else {
      medicalHistory.history.push({
        date: new Date(),
        description: description,
        docs: docs,
        doctor: req.user.name,
        hospital: req.user.hospital,
        Issue: Issue,
        Remark: Remark,
        critical_details: criticalArray || [],
      });
    }
    await medicalHistory.save();

    return res.status(200).json({ message: "Added successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const PatientMedicalHistory = async (req, res) => {
  try {
    const { patientId } = req.params;
    const healthHistory = await medicalHistoryModel.findOne({
      patient: patientId,
    });
    if (!healthHistory) {
      return res.status(400).json({ error: "Invalid Token" });
    }
    const history = healthHistory.history;
    const patient = await patientModel.findOne({ _id: patientId });
    res.status(200).json({
      history,
      alchohol: patient.alchohol,
      no_of_meals: patient.no_of_meals,
      diet: patient.diet,
      smoking: patient.smoking,
      exercise: patient.exercise,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

export {
  DoctorRegistration,
  DoctorLogin,
  updateDoctorDetails,
  sendVerification,
  verifyPhone,
  sendVerifyCode,
  Verifycode,
  newPassword,
  changePassword,
  doctorSchedule,
  updateSchedule,
  updatePatientMedicalHistory,
  getDoctor,
  PatientMedicalHistory,
  getDoctorSchedule,
};
