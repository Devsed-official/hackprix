import AdminModel from "../models/admin.js";
import categoryModel from "../models/doctorCategories.js";
import hospitalModel from "../models/hospital.js"
import jwt from "jsonwebtoken"
import testModel from "../models/tests.js";
import testProvidersModel from "../models/testProviders.js";
import bookedReportSlotModel from "../models/bookedReportSlots.js";

const addAdminUser = async (req, res) => {
    try {
        const user = await new AdminModel({
            email: req.body.email,
        });
        await user.save();

        const encryptedPassword = await user.encryptPassword(req.body.password);
        user.password = encryptedPassword;
        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        user.token = token;
        await user.save();

        res.status(201).json({ message: "Added Succesfully" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const adminLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await AdminModel.findOne({ email });
        if (!user) {
            return res.status(401).json({ error: "Invalid Credentials" });
        }

        const isPasswordValid = await user.validatePassword(password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: "Invalid Credentials" });
        }

        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        user.token = token;
        await user.save();

        res
            .status(200)
            .json({ email: user.email, token: user.token, name: "Admin" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};

const addHospital = async (req, res) => {
    try {

        const { name, description, facilities, email, password } = req.body;
        const exists = await hospitalModel.findOne({ name: name })
        if (exists) {
            return res.status(200).json({ error: "Already Exists" })
        }
        const hospital = new hospitalModel({
            email: email,
            name: name,
            description: description,
            facilities: facilities
        })

        await hospital.save()

        const encryptedPassword = await hospital.encryptPassword(password);
        hospital.password = encryptedPassword;
        const token = jwt.sign({ id: hospital.id }, process.env.JWT_SECRET, {
            expiresIn: "30d",
        });
        hospital.token = token;
        await hospital.save();

        res.status(200).json({ message: "Hospital added successfully" });
    } catch (error) {
        console.log(error);
        return res.status(404).json({ error: "Internal Server Error" })
    }
}

const addCategories = async (req, res) => {
    try {
        const { categories } = req.body;
        for (const cat of categories) {
            const category = new categoryModel({
                name: cat
            })
            await category.save()
        }
        return res.status(200).send("done");
    } catch (error) {
        console.log(error);
        return res.status(404).json({ error: "Internal Server Error" })
    }
}

const addTests = async (req, res) => {
    try {
        const { tests } = req.body;
        for (const cat of tests) {
            const category = new testModel({
                name: cat
            })
            await category.save()
        }
        return res.status(200).send("done");
    } catch (error) {
        console.log(error);
        return res.status(404).json({ error: "Internal Server Error" })
    }
}

const addTestProvider = async (req, res) => {
    try {
        const testProvider = new testProvidersModel({
            name: "Hackprix Labs",
            testAvailable: [
                "Diabetes Test",
                "Cholesterol Test",
                "Blood Pressure Test",
                "Complete Blood Count (CBC)",
                "Liver Function Test",
                "Kidney Function Test",
                "Thyroid Function Test",
                "Electrocardiogram (ECG)",
                "Chest X-ray",
                "Urine Analysis",
                "MRI Scan",
                "CT Scan",
                "Mammogram",
                "Pap Smear",
                "Prostate-Specific Antigen (PSA) Test",
                "Bone Density Test",
                "Allergy Test",
                "HIV Test",
                "Hepatitis Test",
                "Pregnancy Test",
                "Pulmonary Function Test",
                "Stool Test",
                "Vitamin D Test",
                "Iron Test",
                "C-Reactive Protein (CRP) Test"
            ]
        })
        await testProvider.save();
        const bookedSlots = new bookedReportSlotModel({
            name: "Hackprix Labs"
        })
        await bookedSlots.save()
        res.send("done");
    } catch (error) {
        console.log(error);
        return res.status(404).json({ error: "Internal Server Error" })
    }
}

export {
    addAdminUser,
    adminLogin,
    addHospital,
    addCategories,
    addTests,
    addTestProvider
}