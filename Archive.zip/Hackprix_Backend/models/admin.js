import mongoose from "mongoose";
import bcrypt from "bcrypt";

const AdminSchema = mongoose.Schema({
    email: {
        type: String
    },
    password: {
        type: String
    },
    token: {
        type: String
    },
    isAdmin:{
        type: Boolean,
        default: true   
    }
})

AdminSchema.methods.encryptPassword = async function (password) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
};

AdminSchema.methods.validatePassword = function (password) {
    if (!this.password) {
        return Promise.resolve(false);
    }
    return bcrypt.compare(password, this.password);
};

const AdminModel = mongoose.model("Admin", AdminSchema);
export default AdminModel;