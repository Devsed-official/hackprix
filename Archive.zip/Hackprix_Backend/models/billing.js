import mongoose from "mongoose";

const billingSchema = mongoose.Schema({
    patient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Patient",
    },
    total: {
        type: Number,
        default: 0
    },
    history: [
        {
            hospital: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Hospital",
            },
            doctor: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Hospital",
            },
            amount: {
                type: Number
            }
        }
    ]
})