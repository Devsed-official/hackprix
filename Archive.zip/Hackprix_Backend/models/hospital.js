import mongoose from "mongoose";
import bcrypt from "bcrypt";

const hospitalSchema = mongoose.Schema({
    email: {
        type: String
    },
    password: {
        type: String
    },
    name: {
        type: String
    },
    phone: {
        type: String
    },
    desciption: {
        type: String
    },
    facilities: [
        {
            type: String
        }
    ],
    doctors: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Doctor",
        }
    ],
    patients: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Patient",
        }
    ],
    token: {
        type: String
    },
    otp: {
        type: String
    },
    verification: {
        type: String
    }
})

hospitalSchema.methods.encryptPassword = async function (password) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
};

hospitalSchema.methods.validatePassword = function (password) {
    if (!this.password) {
        return Promise.resolve(false);
    }
    return bcrypt.compare(password, this.password);
};

const hospitalModel = mongoose.model("Hospital", hospitalSchema);

export default hospitalModel;