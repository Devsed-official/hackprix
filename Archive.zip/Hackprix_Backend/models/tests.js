import mongoose from "mongoose";

const testSchema = mongoose.Schema({
    name: {
        type: String
    }
})

const testModel = mongoose.model("Tests", testSchema);
export default testModel;