import mongoose from "mongoose";

const medicalHistorySchema = ({
    patient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Patient",
    },
    history: [
        {
            date: {
                type: Date
            },
            description: {
                type: String
            },
            critical_details:[
                {
                    description: {
                        type: String
                    },
                    value: {
                        type: String
                    }
                }
            ],
            doctor:{
                type: String
            },
            hospital: {
                type: String
            },
            Issue: {
                type: String
            },
            Remark: {
                type: String
            },
            docs: [
                {
                    title: {
                        type: String
                    },
                    url: {
                        type: String
                    }
                }
            ]
        }
    ],
})

const medicalHistoryModel = mongoose.model("Medical_History", medicalHistorySchema);

export default medicalHistoryModel;