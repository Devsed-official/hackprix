import mongoose from "mongoose";

const testProvidersSchema = mongoose.Schema({
    hospital: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hospital",
    },
    name: {
        type: String
    },
    testAvailable: [
        {
            type: String
        }
    ]
})

const testProvidersModel = mongoose.model("Test_Provider", testProvidersSchema);
export default testProvidersModel;