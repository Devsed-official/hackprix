import mongoose from "mongoose";

const bookedReportSlot = mongoose.Schema({
    hospital: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hospital",
    },
    name: {
        type: String
    },
    slots: [
        {
            testId: {
                type: String
            },
            date: {
                type: String
            },
            time: {
                type: String
            },
            patient: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Patient",
            },
            tests: [
                {
                    type: String
                }
            ],
            status: {
                type: Boolean,
                default: false
            }
        }
    ]
})

const bookedReportSlotModel = mongoose.model("Booked_Reports_Slot", bookedReportSlot);
export default bookedReportSlotModel;