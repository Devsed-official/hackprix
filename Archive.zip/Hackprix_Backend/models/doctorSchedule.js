import mongoose from "mongoose";

const doctorScheduleSchema = new mongoose.Schema({
    doctor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Doctor",
    },
    sessions: [
        {
            day: {
                type: String,
                required: true,
            },
            time_slot: {
                start_time: String,
                end_time: String,
            },
            slots: [
                {
                    name: { type: String },
                    start_time: { type: String },
                },
            ],
        }
    ]
});

const doctorScheduleModel = mongoose.model(
    "Doctor_Schedule",
    doctorScheduleSchema
);

export default doctorScheduleModel;