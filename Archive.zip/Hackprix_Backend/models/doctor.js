import mongoose from "mongoose";
import bcrypt from "bcrypt";

const doctorSchema = mongoose.Schema({
    name: {
        type: String
    },
    phone: {
        type: String
    },
    gender: {
        type: String
    },
    dob:{
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    otp: {
        type: String
    },
    specialization: {
        type: String
    },
    designation: {
        type: String
    },
    token: {
        type: String
    },
    verification: {
        type: String
    },
    hospital: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Hospital",
    },
    openToSessions: {
        type: Boolean,
        default: false
    },
    patients: [
        {
            patient: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Patient",
            },
            active: {
                type: Boolean,
                default: true
            },
            assignedDate: {
                type: String
            },
            endDate: {
                type: String
            }
        }
    ]
})


doctorSchema.methods.encryptPassword = async function (password) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
};

doctorSchema.methods.validatePassword = function (password) {
    if (!this.password) {
        return Promise.resolve(false);
    }
    return bcrypt.compare(password, this.password);
};

const doctorModel = mongoose.model("Doctor", doctorSchema);

export default doctorModel;