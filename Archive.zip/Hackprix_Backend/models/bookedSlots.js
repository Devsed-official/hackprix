import mongoose from "mongoose";

const bookedSlotsSchema = mongoose.Schema({
    doctor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Doctor",
    },
    slots: [
        {
            date: {
                type: String
            },
            slot: {
                name: { type: String },
                start_time: { type: String },
                patient: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: "Patient",
                },
                slotId: {
                    type: String
                }
            }
        }
    ]
})

const bookedSlotsModel = mongoose.model("Booked_Slots", bookedSlotsSchema);

export default bookedSlotsModel;

