import mongoose from "mongoose";
import bcrypt from "bcrypt";

const patientSchema = mongoose.Schema({
    name: {
        type: String
    },
    phone: {
        type: String
    },
    email: {
        type: String
    },
    gender: {
        type: String
    },
    dob: {
        type: String
    },
    password: {
        type: String
    },
    otp: {
        type: String
    },
    designation: {
        type: String
    },
    token: {
        type: String
    },
    verification: {
        type: String
    },
    alchohol: {
        type: String
    },
    no_of_meals: {
        type: String 
    },
    socialId: {
        type: String
    },
    diet: {
        type: String
    },
    smoking: {
        type: String
    },
    exercise: {
        type: String
    },
    doctors: [
        {
            doctor: {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Doctor",
            },
            active: {
                type: Boolean,
                default: true
            },
            assignedDate: {
                type: String
            },
            endDate: {
                type: String
            }
        }
    ],
    bankAccountDetails: {
        type: String
    },
    charity: {
        type: Boolean,
        default: false
    }
})

patientSchema.methods.encryptPassword = async function (password) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
};

patientSchema.methods.validatePassword = function (password) {
    if (!this.password) {
        return Promise.resolve(false);
    }
    return bcrypt.compare(password, this.password);
};


const patientModel = mongoose.model("Patient", patientSchema);

export default patientModel;