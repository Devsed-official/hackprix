import mongoose from "mongoose";

const reportSchema = mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Patient",
  },
  history: [
    {
      issuer: {
        type: String,
      },
      testId: {
        type: String,
      },
      biologicalname: {
        type: String,
      },
      price: {
        type: Number,
      },
      date: {
        type: Date,
      },
      title: {
        type: String,
      },
      description: {
        type: String,
      },
      parameters: [
        {
          title: {
            type: String,
          },
          subParameters: [
            {
              title: {
                type: String,
              },
              description: {
                type: String,
              },
            },
          ],
        },
      ],
    },
  ],
});

const reportModel = mongoose.model("Report", reportSchema);
export default reportModel;
