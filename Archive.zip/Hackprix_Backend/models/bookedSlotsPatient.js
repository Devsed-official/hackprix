import mongoose from "mongoose";

const bookedSlotsStudentsSchema = mongoose.Schema({
    patient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Patient",
    },
    slots: [
        {
            date: {
                type: String
            },
            slot: {
                name: { type: String },
                start_time: { type: String },
                doctor: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: "Doctor",
                },
                slotId: {
                    type: String
                }
            },
            status: {
                type: Boolean,
                default: false
            }
        }
    ]
})

const bookedSlotsStudentModel = mongoose.model("Booked_Slots_Student", bookedSlotsStudentsSchema);

export default bookedSlotsStudentModel;

