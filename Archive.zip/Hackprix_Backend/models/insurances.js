import mongoose from "mongoose";

const insuranceSchema = mongoose.Schema({
    patient: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Patient",
    },
    history: [
        {
            insuranceCompany: {
                type: String
            },
            insuranceNumber: {
                type: String
            },
            package: {
                type: String
            },
            limit: {
                type: Number
            },
            remainingLimit: {
                type: Number
            },
            expiry: {
                type: String
            },
            active: {
                type: Boolean,
                default: true
            },
            eligibleHospitals: {
                type: Array,
                default: [
                    {
                        "name": "Apollo Hospitals",
                        "address": "Jubilee Hills, Hyderabad, Telangana 500033",
                        "contact": "+91 40 2360 7777",
                        "website": "https://www.apollohospitals.com/"
                    },
                    {
                        "name": "Yashoda Hospitals",
                        "address": "Somajiguda, Hyderabad, Telangana 500082",
                        "contact": "+91 40 4567 4567",
                        "website": "https://www.yashodahospitals.com/"
                    },
                    {
                        "name": "Care Hospitals",
                        "address": "Road No.1, Banjara Hills, Hyderabad, Telangana 500034",
                        "contact": "+91 40 3041 8888",
                        "website": "https://www.carehospitals.com/"
                    },
                    {
                        "name": "KIMS Hospitals",
                        "address": "Secunderabad, Hyderabad, Telangana 500003",
                        "contact": "+91 40 4488 5000",
                        "website": "https://www.kimshospitals.com/"
                    },
                    {
                        "name": "MaxCure Hospitals",
                        "address": "Madhapur, Hyderabad, Telangana 500081",
                        "contact": "+91 40 4940 4940",
                        "website": "https://www.maxcurehospitals.com/"
                    },
                    {
                        "name": "Rainbow Children's Hospital",
                        "address": "Banjara Hills, Hyderabad, Telangana 500034",
                        "contact": "+91 40 2341 2341",
                        "website": "https://www.rainbowhospitals.in/"
                    },
                    {
                        "name": "AIG Hospitals",
                        "address": "Gachibowli, Hyderabad, Telangana 500032",
                        "contact": "+91 40 4244 4244",
                        "website": "https://aighospitals.com/"
                    },
                    {
                        "name": "Global Hospitals",
                        "address": "Lakdi-ka-pul, Hyderabad, Telangana 500004",
                        "contact": "+91 40 2324 4444",
                        "website": "https://www.gleneaglesglobalhospitals.com/"
                    },
                    {
                        "name": "Continental Hospitals",
                        "address": "Nanakramguda, Hyderabad, Telangana 500032",
                        "contact": "+91 40 6700 0000",
                        "website": "https://continentalhospitals.com/"
                    },
                    {
                        "name": "Asian Institute of Gastroenterology",
                        "address": "Somajiguda, Hyderabad, Telangana 500082",
                        "contact": "+91 40 2337 8888",
                        "website": "https://www.aigindia.net/"
                    }
                ]

            }
        }
    ]
})

const insuranceModel = mongoose.model("Insurance", insuranceSchema);
export default insuranceModel;