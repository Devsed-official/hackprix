import jwt from "jsonwebtoken";
import patientModel from "../models/patient.js";
import doctorModel from "../models/doctor.js";
import hospitalModel from "../models/hospital.js";
import AdminModel from "../models/admin.js";

const protectPatient = async (req, res, next) => {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Access Denied" });
    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        // console.log("Token verified:", verified); // Log for debugging
        const id = verified.id;
        req.user = await patientModel.findOne({ _id: id });
        // console.log("User found:", req.user); // Log for debugging
        next();
    } catch (err) {
        console.error("Error in protect middleware:", err);
        res.status(400).json({ message: "Not Authorized" });
    }
};

const protectDoctor = async (req, res, next) => {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Access Denied" });
    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        // console.log("Token verified:", verified); // Log for debugging
        const id = verified.id;
        req.user = await doctorModel.findOne({ _id: id });
        // console.log("User found:", req.user); // Log for debugging
        next();
    } catch (err) {
        console.error("Error in protect middleware:", err);
        res.status(400).json({ message: "Not Authorized" });
    }
};

// const protectCourseUploader = async (req, res, next) => {
//   const token = req.headers["authorization"]?.split(" ")[1];
//   if (!token) return res.status(401).json({ message: "Access Denied" });
//   try {
//     const verified = jwt.verify(token, process.env.JWT_SECRET);
//     // console.log("Token verified:", verified); // Log for debugging
//     const id = verified.id;
//     req.user = await courseUploaderModel.findOne({ _id: id });
//     // console.log("User found:", req.user); // Log for debugging
//     next();
//   } catch (err) {
//     console.error("Error in protect middleware:", err);
//     res.status(400).json({ message: "Not Authorized" });
//   }
// };

const protect = async (req, res, next) => {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Access Denied" });
    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        // console.log("Token verified:", verified); // Log for debugging   
        const id = verified.id;
        req.user = await AdminModel.findOne({ _id: id });
        // console.log("User found:", req.user); // Log for debugging
        next();
    } catch (err) {
        console.error("Error in protect middleware:", err);
        res.status(400).json({ message: "Not Authorized" });
    }
};

const protectHospital = async (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Access Denied' });
    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        // console.log("Token verified:", verified); // Log for debugging
        const id = verified.id;
        req.user = await hospitalModel.findOne({ _id: id });
        // console.log("User found:", req.user); // Log for debugging
        next();
    } catch (err) {
        console.error("Error in protect middleware:", err);
        res.status(400).json({ message: 'Not Authorized' });
    }
};

const checkAdmin = (req, res, next) => {
    // console.log(req.user);
    if (!req.user.isAdmin)
        return res.status(403).json({ message: "Access Denied" });
    next();
};
export { protectDoctor, protectPatient, protectHospital, protect, checkAdmin };
