import express from "express";
import morgan from 'morgan';
import dotenv from 'dotenv';
import mongoose from "mongoose";
import cors from "cors"
import path from "path";
dotenv.config();

import patientRoute from "./routes/patientRoute.js"
import doctorRoute from "./routes/doctorRoute.js"
import hospitalRoute from "./routes/hospitalRoute.js"
import adminRoute from "./routes/adminRoute.js"
import generalRoute from "./routes/generalRoute.js"
import passport from "passport";
import session from "express-session";
import { fileURLToPath } from "url";
import "./utils/passport.js";


const app = express();
app.use(cors())
app.use(morgan("dev"));
app.use(express.json())


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDirectory = path.join(__dirname, "public");

mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("Connected Successfully... "))
    .catch((e) => console.log(e));

app.use("/api/v1/patient", patientRoute);
app.use("/api/v1/doctor", doctorRoute);
app.use("/api/v1/hospital", hospitalRoute);
app.use("/api/v1/admin", adminRoute);
app.use("/api/v1/general", generalRoute);

//google
app.use(session({ secret: "secret", resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static(publicDirectory));

app.listen(3001, (req, res) => {
    console.log("Server Running...")
})