import axiosInstance from "./axiosinstance";
import { getToken } from "./getToken";

const addSubject = async (
  description,
  patientId,
  issue,
  remark,
  critical,
  file
) => {
  const token = getToken();
  const headers = {
    authorization: `Bearer ${token}`,
    "Content-Type": "multipart/form-data", // Needed for file uploads
  };

  const requestData = new FormData();
  if (file) {
    requestData.append("documents", file);
  }

  try {
    const response = await axiosInstance.post(
      `/doctor/addPatientMedicalHistory?description=${description}&patientId=${patientId}&Issue=${issue}&Remark=${remark}&critical=${critical}`,
      requestData,
      { headers }
    );
    return response.data;
  } catch (error) {
    console.log(error);
    return error.response.data;
  }
};

export default addSubject;
