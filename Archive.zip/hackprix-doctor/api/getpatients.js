import axiosInstance from "./axiosinstance";
const GetaPatients = async (token) => {
  const headers = {
    authorization: `Bearer ${token}`,
  };
  try {
    const response = await axiosInstance.get("/general/patients", {
      headers,
    });

    return response.data;
  } catch (error) {
    console.log(error);
    return error.response.data;
  }
};
export default GetaPatients;
