import axiosInstance from "./axiosinstance";
const GetallCategories = async (token) => {
  const headers = {
    authorization: `Bearer ${token}`,
  };
  try {
    const response = await axiosInstance.get("/general/categories", {
      headers,
    });

    return response.data;
  } catch (error) {
    console.log(error);
    return error.response.data;
  }
};
export default GetallCategories;
