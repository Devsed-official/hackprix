export const BASE_URL = "http://localhost:3001/api/v1/";
// export const BASE_URL = "https://backend.zainii.com:8443/api/v1/";
export const BACK_KEY = "hdDnIKsddcsS3fsdn3DAdsf";
export const IMGBASE_URL = "http://localhost:3001/api/v1";
