import axiosInstance from "./axiosinstance";
import { getToken } from "./getToken";
const updateHabits = async (drinkingHabits) => {
  const requestData = {
    specialization: drinkingHabits,
  };
  const token = getToken();
  const headers = {
    authorization: `Bearer ${token}`,
  };
  try {
    const response = await axiosInstance.post("/doctor/update", requestData, {
      headers,
    });
    return response.data;
  } catch (error) {
    return error.response.data;
  }
};
export default updateHabits;
