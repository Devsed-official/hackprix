"use client";
import addSubject from "@/api/addSubject";
import Button from "@/components/button";
import { toast } from "@/components/ui/use-toast";
import { Upload } from "@/public/icons/dashboard";
import Preview1 from "@/public/icons/preview1";
import Removefile from "@/public/icons/removefile";
import { useUser } from "@/redux/userContext";
import getFormattedDate from "@/utils/getFormattedDate";
import clsx from "clsx";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useRef, useState } from "react";

const Addmedicalhistory = () => {
  const fileInputRef = useRef(null);
  const params = useSearchParams();

  const [pageload, setpageload] = useState(true);
  const patientId = params.get("id");
  console.log(patientId, "iddddddddddddd");
  const [date, setdate] = useState(getFormattedDate());
  const { state } = useUser();
  const user = state.user;
  const [file, setFile] = useState(null);
  const [subject, setsubject] = useState();
  const [subtitle, setsubtitle] = useState();
  const [description, setDescription] = useState();
  const [issue, setIssue] = useState();
  const [remark, setRemark] = useState();
  const [critical, setCritical] = useState([
    { description: "Heart rate", value: "" },
    { description: "BMI", value: "" },
    { description: "Sugar level (before fasting)", value: "" },
    { description: "Sugar level (after fasting)", value: "" },
  ]);
  const [isDragging, setIsDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const route = useRouter();

  const previewFile = () => {
    if (file) {
      const fileURL = URL.createObjectURL(file);
      window.open(fileURL, "_blank");
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(true);
  };

  const handleDragEnter = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsDragging(false);
    const droppedFile = event.dataTransfer.files[0];
    setFile(droppedFile);
  };

  const handleChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
  };

  const handleCriticalChange = (index, value) => {
    const newCritical = [...critical];
    newCritical[index].value = value;
    setCritical(newCritical);
  };

  useEffect(() => {
    if (user) {
      setpageload(false);
    }
  }, [user]);

  const submit = async () => {
    console.log(
      "working",
      subject,
      subtitle,
      description,
      file,
      issue,
      remark,
      critical
    );

    // Validate required fields
    if (!subject) {
      toast({ title: "Incident Name is required" });
    } else if (!description) {
      toast({ title: "Description is required" });
    } else if (!file) {
      toast({ title: "Logo is required" });
    } else if (!issue) {
      toast({ title: "Issue is required" });
    } else if (!remark) {
      toast({ title: "Remark is required" });
    } else {
      // Validate critical field values
      const invalidCritical = critical.some((item) => !item.value);
      if (invalidCritical) {
        toast({ title: "All critical fields are required" });
      } else {
        const stringarr = JSON.stringify(critical);
        console.log("Working");
        setLoading(true);
        console.log(stringarr);
        const data = await addSubject(
          description,
          patientId,
          issue,
          remark,
          stringarr,
          file
        );
        if (!data.error) {
          toast({ title: "Added Medical history Successfully" });
        } else {
          toast({ title: "Something went wrong try again later" });
        }
        setLoading(false);
      }
    }
  };

  return (
    <div className="h-full w-full">
      {pageload ? (
        <div className="h-[100%] w-full flex justify-center items-center">
          <div className="loader-line"></div>
        </div>
      ) : (
        <div className="h-full pb-20 relative">
          <div
            onDragOver={handleDragOver}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className="flex relative flex-col h-[100%]"
          >
            <div className="w-full sticky top-0 bg-white border-b-[1px] border-[#E2E4E8]"></div>
            <div
              id="nested-content"
              className="min-w-[100%] p-[1.5rem] relative max-h-[100%] overflow-y-scroll"
            >
              <div className="sticky top-0  bg-white py-[1rem]">
                <div className=" font-thunder font-bold text-[2rem] md:text-[6rem] md:max-w-[600px] md:leading-[6rem] leading-tight up fontstyle">
                  ADD NEW MEDICAL HISTORY
                </div>
              </div>
            </div>
            <div className=" h-full  w-[100%]   ">
              <div className=" grid grid-cols-2  w-[80%] 2xl:w-[70%] gap-x-[5rem]  gap-y-[3rem] p-[1.5rem]">
                <div className=" flex flex-col gap-2">
                  <div className=" font-circular font-medium text-[1.1rem]">
                    Incident Name
                  </div>
                  <input
                    onChange={(e) => {
                      setsubject(e.target.value);
                    }}
                    value={subject}
                    className=" outline-none cursor-pointer focus:border-[#205FFF] bg-[#FAFBFC] w-[100%]   px-2 py-2.5 border-[#EDEEF4] border-[1px]  text-[1rem]  font-Matter  rounded-lg"
                    placeholder="Enter Name"
                    type="text"
                  />
                </div>
                <div className=" flex flex-col gap-2"></div>
                <div className={clsx(" flex flex-col gap-2")}>
                  <div className="  font-circular font-medium text-[1.1rem]">
                    Incident Details
                  </div>

                  <textarea
                    onChange={(e) => {
                      setDescription(e.target.value);
                    }}
                    className=" outline-none cursor-pointer border-[#EDEEF4] border-[1px] min-h-[140px] focus:border-[#205FFF] bg-[#FAFBFC] w-[100%] px-2 py-2  text-[.9rem]  font-Matter  rounded-xl"
                    placeholder="Heart attack, Diabetes"
                    value={description}
                  />
                </div>
                <div className={clsx(" flex flex-col gap-2")}></div>
                <div className={clsx(" flex flex-col gap-2")}>
                  <div className="  font-circular font-medium text-[1.1rem]">
                    Issue
                  </div>
                  <input
                    onChange={(e) => {
                      setIssue(e.target.value);
                    }}
                    value={issue}
                    className=" outline-none cursor-pointer focus:border-[#205FFF] bg-[#FAFBFC] w-[100%]   px-2 py-2.5 border-[#EDEEF4] border-[1px]  text-[1rem]  font-Matter  rounded-lg"
                    placeholder="Enter Issue"
                    type="text"
                  />
                </div>
                <div className={clsx(" flex flex-col gap-2")}>
                  <div className="  font-circular font-medium text-[1.1rem]">
                    Remark
                  </div>
                  <input
                    onChange={(e) => {
                      setRemark(e.target.value);
                    }}
                    value={remark}
                    className=" outline-none cursor-pointer focus:border-[#205FFF] bg-[#FAFBFC] w-[100%]   px-2 py-2.5 border-[#EDEEF4] border-[1px]  text-[1rem]  font-Matter  rounded-lg"
                    placeholder="Enter Remark"
                    type="text"
                  />
                </div>
                {critical.map((item, index) => (
                  <div key={index} className={clsx(" flex flex-col gap-2")}>
                    <div className="  font-circular font-medium text-[1.1rem]">
                      {item.description}
                    </div>
                    <input
                      onChange={(e) =>
                        handleCriticalChange(index, e.target.value)
                      }
                      value={item.value}
                      className=" outline-none cursor-pointer focus:border-[#205FFF] bg-[#FAFBFC] w-[100%]   px-2 py-2.5 border-[#EDEEF4] border-[1px]  text-[1rem]  font-Matter  rounded-lg"
                      placeholder={`Enter ${item.description}`}
                      type="text"
                    />
                  </div>
                ))}
                <div className={clsx(" flex flex-col gap-2")}>
                  <div className=" font-circular font-medium text-[1.1rem] ">
                    Upload Reports
                  </div>

                  <div
                    className={clsx(
                      " border-[1px] h-[140px] bg-[#FAFBFC] w-[100%]  select-none rounded-lg  cursor-pointer  ",
                      !isDragging ? "border-[#EDEEF4]" : "border-[#205FFF]"
                    )}
                  >
                    <div
                      onClick={() => {
                        fileInputRef.current.click();
                      }}
                      className={clsx(file ? "hidden" : "py-[2rem]")}
                    >
                      <input
                        type="file"
                        id="fileInput"
                        ref={fileInputRef}
                        onChange={handleChange}
                        style={{ display: "none" }}
                        accept=".jpeg,.jpg,.png,.pdf"
                      />
                      <div className=" font-Matter text-[#4B5563]  mx-auto w-[250px] font-medium">
                        <div className=" flex items-center justify-center gap-2">
                          <Upload /> Upload Logo
                        </div>
                        <div className=" text-center text-[#9CA3AF] font-normal pt-2 text-[0.9rem]">
                          Click here or drag and drop a file to upload.
                        </div>
                      </div>
                    </div>
                    <div
                      id="fileList"
                      className={clsx(
                        " h-full w-full flex justify-center items-center",
                        file ? "" : " hidden"
                      )}
                    >
                      <div className=" w-[200px] flex flex-col gap-2">
                        <div className=" relative border-[#E4E4E4] flex items-center px-3 py-2 gap-2 w-full border-[1px]  rounded-lg ">
                          <Preview1 />
                          <div className=" leading-none flex flex-col gap-[0.25rem]">
                            <div className=" font-Matter text-[0.9rem] text-[#3C3C3C]">
                              {file?.name.length > 20
                                ? `${file?.name.substring(0, 20)}...`
                                : file?.name}
                            </div>
                            <div className=" font-Matter font-medium text-[0.9rem] text-[#999999]">
                              {(file?.size / (1024 * 1024)).toFixed(2)} MB
                            </div>
                          </div>
                          <div
                            onClick={() => {
                              setFile(null);
                            }}
                            className=" absolute -top-1  -right-1"
                          >
                            <Removefile />
                          </div>
                        </div>
                        <div
                          onClick={previewFile}
                          className=" font-Matter  underline text-[#205FFF] text-center"
                        >
                          Preview
                        </div>
                      </div>
                      <div></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className=" sticky xl:fixed  bottom-0  w-full  p-[1rem] ">
            <div className=" border-[#E4E4E5] border-[1px] bg-white pl-4  pr-2 flex justify-between  items-center leading-none  py-2 rounded-full">
              <div className=" flex items-center leading-none gap-5">
                <div className=" font-Matter font-medium ">
                  Select Time Slots
                </div>
              </div>
              <div className=" flex gap-4 items-center">
                <div
                  onClick={() => {
                    submit();
                  }}
                >
                  <Button
                    wfull={"min-w-[90px]"}
                    className={clsx(" text-white bg-[#205FFF]")}
                    text={!loading ? "Update" : <div className="loader" />}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Addmedicalhistory;
