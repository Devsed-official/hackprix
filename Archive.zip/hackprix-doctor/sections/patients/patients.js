"use client";
import GetaPatients from "@/api/getpatients";
import Padding from "@/components/padding";
import clsx from "clsx";
import Link from "next/link";
import React, { useEffect, useState } from "react";

const Patients = () => {
  const [loading, setloading] = useState(true);
  const [data, setdata] = useState();
  useEffect(() => {
    const getdata = async () => {
      const res = await GetaPatients();
      console.log(res);
      setdata(res);
      if (res) {
        setloading(false);
      }
    };
    getdata();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[100vh] ">
        <div className=" loader-line "></div>
      </div>
    );
  }

  return (
    <div className=" py-8 ">
      <Padding>
        <div>
          <div>
            <div className=" border-[#F0F0F0] w-[100%]   border-[1px] rounded-3xl">
              <div className=" flex gap-2  font-circular text-[#000000]  font-medium rounded-t-3xl bg-[#FAFBFD] border-b-[1px] border-[#D9E1F1] py-[1rem] ">
                <div className="w-[10%]   flex justify-center">S.No</div>
                <div className=" w-[20%]  flex">Name</div>
                <div className=" w-[20%]  flex justify-center">Email</div>
                <div className=" w-[20%]  flex justify-center">Gender</div>
                <div className=" w-[20%]  flex justify-center"> </div>
              </div>
              {data.map((item, index) => (
                <div
                  key={index}
                  className={clsx(
                    "flex gap-2 font-circular text-[#000000] py-[1rem]",
                    index % 2 !== 0 ? "bg-[#F9FBFC]" : "bg-white"
                  )}
                >
                  <div className="w-[10%] items-center flex justify-center">
                    {index + 1}
                  </div>
                  <div className="w-[20%] items-center flex">{item.name}</div>
                  <div className="w-[20%] items-center flex justify-center">
                    {item.email}
                  </div>
                  <div className="w-[20%] items-center     flex justify-center">
                    {item.gender}
                  </div>
                  <div className="w-[20%] flex underline underline-offset-2 justify-center">
                    <Link href={`/dashboard/medicalhistory?id=${item._id}`}>
                      Medical history & Tests
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Padding>
    </div>
  );
};

export default Patients;
