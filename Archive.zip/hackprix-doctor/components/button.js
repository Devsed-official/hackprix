import clsx from 'clsx';
import React from 'react';

const Button = ({ text, className, wfull }) => {
  return (
    <div className={clsx(" font-Matter hover:cursor-pointer flex justify-center border-[0] items-center  text-[0.9rem] md:text-[0.9rem] lg:text-[0.95rem] leading-none rounded-full   xl:px-5 xl:py-4   px-5 py-4", className, wfull || "w-max")}>
      {text}
    </div>
  );
}

export default Button;
