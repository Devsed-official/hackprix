"use client";
import React, { useEffect, useState } from "react";
import Padding from "./padding";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { useUser } from "@/redux/userContext";
import { usePathname, useRouter } from "next/navigation";

const Dashboardnavbar = () => {
  const { state } = useUser();
  const user = state.user;
  const route = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!user && !token) {
      route.push("/login");
    }
  }, [user]);
  const [isactive, setactive] = useState(0);
  return (
    <div className=" py-2">
      <div>
        <div className=" px-[3rem] font-circular text-[1.25rem] py-2 pb-10 ">
          Healthyme
        </div>
        <div className=" px-[3rem]  font-circular border-b border-b-[#DCE2EE] text-[#60636C] flex gap-14 ">
          <Link href={"/dashboard"}>
            <div
              onClick={() => setactive(0)}
              className={clsx(
                " pb-2 translate-y-[1px] cursor-pointer duration-300 relative ",
                pathname == "/dashboard"
                  ? "text-[#52C509]   "
                  : "text-[#60636C] "
              )}
            >
              Overview
              {pathname == "/dashboard" && (
                <motion.div
                  layoutId="tabs"
                  className=" absolute h-[1px] w-full bottom-0 bg-[#52C509] "
                ></motion.div>
              )}
            </div>
          </Link>
          <Link href={"/dashboard/patients"}>
            <div
              className={clsx(
                " pb-2 translate-y-[1px] cursor-pointer duration-300 relative ",
                pathname.includes("patients")
                  ? "text-[#52C509]   "
                  : pathname.includes("medicalhistory")
                  ? "text-[#52C509] "
                  : "text-[#60636C] "
              )}
              onClick={() => setactive(1)}
            >
              Patients
              {pathname.includes("patients") ||
                (pathname.includes("medicalhistory") && (
                  <motion.div
                    layoutId="tabs"
                    className=" absolute h-[1px] w-full bottom-0 bg-[#52C509] "
                  ></motion.div>
                ))}
            </div>
          </Link>
          <Link href={"/dashboard/appointments"}>
            <div
              onClick={() => setactive(2)}
              className={clsx(
                " pb-2 translate-y-[1px] relative cursor-pointer duration-300 ",
                isactive == 2 ? "text-[#52C509]   " : "text-[#60636C] "
              )}
            >
              Appointments
              {isactive == 2 && (
                <motion.div
                  layoutId="tabs"
                  className=" absolute h-[1px] w-full bottom-0 bg-[#52C509] "
                ></motion.div>
              )}
            </div>
          </Link>
          <Link href={"/dashboard/medicaltest"}>
            <div
              onClick={() => setactive(3)}
              className={clsx(
                " pb-2 translate-y-[1px] relative cursor-pointer duration-300 ",
                isactive == 3 ? "text-[#52C509]   " : "text-[#60636C] "
              )}
            >
              Medical tests
              {isactive == 3 && (
                <motion.div
                  layoutId="tabs"
                  className=" absolute h-[1px] w-full bottom-0 bg-[#52C509] "
                ></motion.div>
              )}
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboardnavbar;
