import React from 'react'

const Removefile = () => {
  return (
    <div>
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="8" cy="8" r="7.5" fill="white" stroke="#E4E4E4"/>
<path d="M5 11.0508L11.0502 5.00053" stroke="#7E7E7E" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11.0502 11.0502L5 5" stroke="#7E7E7E" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

    </div>
  )
}

export default Removefile
