import Personaldetails from '@/sections/personaldetails/personaldetails'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Personaldetails />
        </div>
    )
}

export default Page
