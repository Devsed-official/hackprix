import Signup from "@/sections/signup/signup";
import React from "react";

const Page = () => {
  return (
    <div>
      <Signup />
    </div>
  );
};

export default Page;
