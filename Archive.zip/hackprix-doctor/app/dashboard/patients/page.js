import Patients from "@/sections/patients/patients";
import React from "react";

const Page = () => {
  return (
    <div>
      <Patients />
    </div>
  );
};

export default Page;
