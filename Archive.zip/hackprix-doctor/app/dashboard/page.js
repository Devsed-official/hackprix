"use client"
import calculateCountdown from "@/utils/calculateCountdown";
import clsx from "clsx";
import React, { useEffect, useState } from "react";
import src from "@/public/images/profile.png";
import Image from "next/image";
import joinMeeting from "@/api/joinMeeting";


const Page = () => {
  const [countdown, setCountdown] = useState();

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown(calculateCountdown(data.slot.start_time));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const joinMeet = async () => {
    const data2 = await joinMeeting("66649721128e17afe0a3062c");
    if (data2.toLowerCase().includes("internal server error")) {
      toast({ title: "Something went wrong, please try again later" });
    } else {
      window.open(`/meeting?token=${data2}`, "_blank");
    }
  }

  const data = {
    date: "2024-06-11",
    slot: {
      start_time: "00:00",
      patient: {
        name: "Affan Khan Osmani"
      },
      slotId: "66649721128e17afe0a3062c",
      status: false
    }
  }
  return <div>
    <div
      className={clsx(
        " bg-[#1D55E5] mt-5 px-[3rem] py-8 pt-12 rounded-3xl "
      )}
    >
      <div className=" text-[5rem] pb-20 text-white leading-[5rem] md:max-w-[600px] font-thunder font-bold ">
        YOU HAVE AN UPCOMING APPOINTMENT
      </div>
      <div>
        <div>
          <div className=" text-[#BBD8FA] py-5 font-circular ">
            On{" "}
            <span className=" text-white ">
              {"2024-06-11"}
            </span>
          </div>
        </div>
        <div className=" flex justify-between w-full items-end ">
          <div className=" bg-[#1847C0] font-circular rounded-full flex gap-3 p-3 pr-6 w-max ">
            <Image className=" w-[3rem] " src={src} />
            <div>
              <div className=" text-white ">{data.slot.patient.name}</div>
              <div className=" text-[#8FAAF1] text-[0.9rem] ">
                Cardiologist
              </div>
            </div>
          </div>
          <div onClick={() => joinMeet()} className="cursor-pointer text-white bg-[#1847C0] font-circular py-2 px-5 w-max rounded-full ">
            {countdown}
          </div>
        </div>
      </div>
    </div>
  </div>;
};

export default Page;
