import Medicalhistory from "@/sections/medicalhistory/medicalhistory";
import React from "react";

const Page = () => {
  return (
    <div>
      <Medicalhistory />
    </div>
  );
};

export default Page;
