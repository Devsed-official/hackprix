import Addmedicalhistory from "@/sections/addmedicalhistory/addmedicalhistory";
import React from "react";

const Page = () => {
  return (
    <div>
      <Addmedicalhistory />
    </div>
  );
};

export default Page;
