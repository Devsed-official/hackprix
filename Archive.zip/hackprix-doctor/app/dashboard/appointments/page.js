import Appointments from "@/sections/appointments/appointments";
import React from "react";

const Page = () => {
  return (
    <div>
      <Appointments />
    </div>
  );
};

export default Page;
