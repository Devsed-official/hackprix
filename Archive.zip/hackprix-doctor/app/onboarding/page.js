import Onboarding from '@/sections/onboarding/onboarding'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Onboarding />
        </div>
    )
}

export default Page
