import Forgotpassword from "@/sections/forgotpassword/forgetpassword";
import React from "react";

const Page = () => {
  return (
    <div>
      <Forgotpassword />
    </div>
  );
};

export default Page;
