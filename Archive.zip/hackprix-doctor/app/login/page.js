import Login from '@/sections/login/login'
import React from 'react'

const Page = () => {
  return (
    <div>
        <Login/>
      
    </div>
  )
}

export default Page
