import Meeting from '@/sections/meeting'
import React from 'react'

const Page = () => {
  return (
    <div>
      <Meeting/>
    </div>
  )
}

export default Page
