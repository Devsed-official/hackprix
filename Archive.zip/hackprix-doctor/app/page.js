"use client"
import React from 'react'
import Router, { useRouter } from 'next/navigation'
const Page = () => {
  const rounternew=useRouter()
  return (
    <div>
      {rounternew.push("/signup")}
    </div>
  )
}

export default Page
