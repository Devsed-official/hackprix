const daysOfWeek = [
    { first: "Mon", second: "Monday" },
    { first: "Tue", second: "Tuesday" },
    { first: "Wed", second: "Wednesday" },
    { first: "Thu", second: "Thursday" },
    { first: "Fri", second: "Friday" },
    { first: "Sat", second: "Saturday" },
    { first: "Sun", second: "Sunday" }
  ];
  
  export default daysOfWeek;
  