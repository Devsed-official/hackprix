
import Medicaltdetails from "@/sections/medicaltestdetails/medicaltdetails";
import React from "react";

const Page = () => {
  return <div>
    <Medicaltdetails />
  </div>;
};

export default Page;
