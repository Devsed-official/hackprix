import Medicaltest from "@/sections/medicaltest/medicaltest";
import React from "react";

const Page = () => {
  return (
    <div>
      <Medicaltest />
    </div>
  );
};

export default Page;
