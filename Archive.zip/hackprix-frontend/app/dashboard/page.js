import Dashboard from "@/sections/dashboard/dashboard";
import React from "react";

const Page = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default Page;
