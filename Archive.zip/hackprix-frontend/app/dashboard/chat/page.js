import React from "react";

const Page = () => {
  return (
    <div>
      <Chat />
    </div>
  );
};

export default Page;
