import Singleappointment from '@/sections/singleappointment/singleappointment'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Singleappointment />
        </div>
    )
}

export default Page
