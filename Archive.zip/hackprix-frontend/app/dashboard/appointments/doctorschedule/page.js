import Doctorschedule from '@/sections/doctorschedule/doctorschedule'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Doctorschedule />
        </div>
    )
}

export default Page
