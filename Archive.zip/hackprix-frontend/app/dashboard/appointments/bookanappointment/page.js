import Bookanappointment from '@/sections/bookanappointment/bookanappointment'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Bookanappointment />
        </div>
    )
}

export default Page
