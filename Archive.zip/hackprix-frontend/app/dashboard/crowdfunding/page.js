import Crowdfunding from '@/sections/crowdfunding/crowdfunding'
import React from 'react'

const Page = () => {
    return (
        <div>
            <Crowdfunding />
        </div>
    )
}

export default Page
