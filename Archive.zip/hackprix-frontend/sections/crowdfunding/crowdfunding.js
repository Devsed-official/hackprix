import Crowdfundingcard from '@/components/crowdfundingcard'
import React from 'react'

const Crowdfunding = () => {
    return (
        <div className=' px-[1rem] flex flex-col gap-[1rem]'>
            <Crowdfundingcard />
        </div>
    )
}

export default Crowdfunding
